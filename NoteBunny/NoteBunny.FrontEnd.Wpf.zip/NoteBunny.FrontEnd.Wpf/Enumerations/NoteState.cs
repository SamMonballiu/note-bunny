﻿namespace NoteBunny.FrontEnd.Wpf.Enumerations
{
    public enum NoteState
    {
        View,
        Edit
    }
}
